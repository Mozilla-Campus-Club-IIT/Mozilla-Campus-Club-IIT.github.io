# OfficialWeb

## Official Website of Mozilla Campus Club IIT


This repository contains all resources related to Mozilla Campus Club of Informatics Institute of Technology. Since we are a open source community, you can contribute this repository to make a great website for our club.

Rules and Regulations
* You are not allowed to store unrealated/harmful data in this repository.
* Once you make a change for the repository one of our community leaders will check and approve your contribution.
* Make sure to keep a meaningful commit message when you contribute to this repository.

Let's make it happen...
Happy Coding....

`Note the Preview of the code is available at https://mozilla-campus-club-iit.github.io/`
